package clases;

public class Entrada {
	private int codigoEntrada, cantidadEntrada;
	public Entrada(int codigoEntrada, int cantidadEntrada) {
		super();
		this.codigoEntrada = codigoEntrada;
		this.cantidadEntrada = cantidadEntrada;
	}
	public int getCodigoEntrada() {
		return codigoEntrada;
	}
	public void setCodigoEntrada(int codigoEntrada) {
		this.codigoEntrada = codigoEntrada;
	}
	public int getCantidadEntrada() {
		return cantidadEntrada;
	}
	public void setCantidadEntrada(int cantidadEntrada) {
		this.cantidadEntrada = cantidadEntrada;
	}
	
}
